package com.projeto.amandalopes.repository;


	import org.springframework.data.repository.CrudRepository;
	import com.projeto.amandalopes.model.Contato;

	public interface ContatoRepository extends CrudRepository<Contato, Long>{
		
		

	
		
		
	}
	

