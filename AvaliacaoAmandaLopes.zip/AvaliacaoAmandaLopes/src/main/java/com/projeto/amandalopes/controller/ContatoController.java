package com.projeto.amandalopes.controller;

	
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.servlet.ModelAndView;

import com.projeto.amandalopes.model.Contato;
import com.projeto.amandalopes.repository.ContatoRepository;

	@Controller
	public class ContatoController {
		
		@Autowired
		ContatoRepository contatoRepository;
		
		@GetMapping("/cadastro")
		public ModelAndView cadastro() {
			ModelAndView mv = new ModelAndView();
			mv.addObject("contato", new Contato());
			mv.setViewName("Login/cadastro");
			return mv;
		}
		
	
					
		  @PostMapping("/salvarContato")
		  public String salvarContato( Contato contato) {
	      contatoRepository.save(contato);
	      return "redirect:/form";
		}
		
	

}
