package com.projeto.amandalopes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvaliacaoAmandaLopesApplicationTests {

	@Test
	void contextLoads() {
	}

}
